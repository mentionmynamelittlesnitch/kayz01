GAME HUB

UPLOAD TO GITHUB:
1. Unzip Game-Hub.zip.
2. Open your GitHub Pages repository.
3. Click Add file > Upload files.
4. Drag ALL the items from inside the Game-Hub folder into the upload box:
   index.html
   style.css
   music.html
   wheelie.html
   music folder
5. Commit changes.
6. Go to Settings > Pages.
7. Choose Deploy from a branch > main > /(root) > Save.

IMPORTANT:
The music folder must stay named 'music', and song-1.mp3 must stay inside it.
Only publish music you own or have permission to distribute.
Third-party game links may be restricted by a school/network; this package does not bypass those restrictions.
